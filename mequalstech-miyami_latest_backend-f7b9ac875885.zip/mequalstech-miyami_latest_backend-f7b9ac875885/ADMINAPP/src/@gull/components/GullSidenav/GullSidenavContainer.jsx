import React from "react";

const GullSidenavContainer = ({ children }) => {
  return <div className="gull-sidenav-container">{children}</div>;
};

export default GullSidenavContainer;
