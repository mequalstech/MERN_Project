import React from "react";

const GullSidenavContent = ({ children }) => {
  return <div className={`gull-sidenav-content h-100`}>{children}</div>;
};

export default GullSidenavContent;
