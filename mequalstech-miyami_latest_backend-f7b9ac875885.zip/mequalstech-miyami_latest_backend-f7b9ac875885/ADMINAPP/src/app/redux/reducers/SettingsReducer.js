import {
    CHANGE_PASSWORD
  } from "../actions/SettingsActions";
  
  const initialState = {};
  
  const settingsReducer = function(state = initialState, action) {
    switch (action.type) {
      default: {
        return state;
      }
    }
  };
  
  export default settingsReducer;
  