import { lazy } from "react";

const Layout2 = lazy(() => import("./Layout2/Layout2"));

export const GullLayouts = {
    layout2: Layout2,
};
