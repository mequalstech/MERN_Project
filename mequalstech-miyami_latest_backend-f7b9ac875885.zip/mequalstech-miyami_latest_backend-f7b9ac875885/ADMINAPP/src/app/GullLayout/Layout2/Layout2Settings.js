const layout2Settings = {
  leftSidebar: {
    theme: "gradient-black-blue",
  },
  header: {
    show: true
  },
  searchBox: {
    open: false
  },
  secondarySidebar: { show: false },
};

export default layout2Settings;
