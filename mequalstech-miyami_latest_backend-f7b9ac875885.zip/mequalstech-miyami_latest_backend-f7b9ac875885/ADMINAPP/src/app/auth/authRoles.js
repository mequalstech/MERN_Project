export const authRoles = {
  sa: ['SA'],
  admin: ['SA', 'ADMIN'],
  editor: ['SA', 'ADMIN', 'EDITOR'],
  guest: ['SA', 'ADMIN', 'EDITOR', 'GUEST']
}